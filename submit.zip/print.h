#ifndef PRINT_H
#define PRINT_H

#include "values.h"

void print_result(val_t);

#endif
